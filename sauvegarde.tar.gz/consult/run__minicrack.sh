#!/bin/sh
./mini_crack -xl 3 -xc caracteres -sh cpy_shadow  

