#~/bin/sh
gcc -g -o mini_crack minicrack.c -lcrypt
