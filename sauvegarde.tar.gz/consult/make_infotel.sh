#!/bin/sh
gcc -g -o infotel infotel.c

